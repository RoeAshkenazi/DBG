package com.example.hw2.Interface;

import com.example.hw2.Class.LocationAndScore;

public interface Score_Callback {
    public void showInMap(LocationAndScore locationAndScore);
}
